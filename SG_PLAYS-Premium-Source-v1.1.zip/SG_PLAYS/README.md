# SG_PLAYS — Android source project

A fresh Android lecture-player project using AndroidX Media3 / ExoPlayer.

## Working features in this source version
- Built-in browser with back, forward, refresh, URL field and copy-URL action
- StudyRays quick link
- Import local video/audio using Android's document picker
- Media3 playback with MP4, HLS and DASH modules
- Landscape playback screen
- 10-second rewind and forward
- Playback speed presets from 0.5× to 4×
- Timestamp bookmarks saved locally
- Timestamped lecture notes saved locally
- A–B repeat loop
- Sleep timer (15/30/45/60 minutes)
- Fit / stretch / zoom aspect-ratio modes
- Automatic playback-position saving and resume
- GitHub Actions workflow to build a debug APK

## Build from an Android phone with GitHub
1. Create a GitHub repository.
2. Extract this ZIP and upload the *contents* of the folder to the repository root.
3. Open the repository's **Actions** tab.
4. Run **Build SG_PLAYS APK** (or push to the `main` branch).
5. Open the completed workflow run and download the `SG-PLAYS-APK` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your phone.

## Important technical limitations
- A website's embedded video is not automatically extractable. The browser can display a page, but the native player only plays a direct media URL or a URI the device can access.
- DRM-protected, encrypted, login-restricted or site-controlled streams may not play outside their original website/app.
- Stream quality selection depends on the available HLS/DASH tracks; this version does not yet include a custom quality-track selector.
- This version does not yet implement browser tabs, a download manager, Chromecast, PiP, equalizer, subtitle downloader, or brightness/volume swipe gestures. Those require separate implementation and device testing.
- The sleep timer, bookmarks and notes are stored locally in app preferences. They are not cloud-synced.
- This is a development source build. Test it on a real Android device before treating it as a release.

## Project details
- App label: SG_PLAYS
- Application ID: `com.sgplays.app`
- Min Android: Android 6.0 (API 23)
- Java 17 / Android Gradle Plugin 8.13
