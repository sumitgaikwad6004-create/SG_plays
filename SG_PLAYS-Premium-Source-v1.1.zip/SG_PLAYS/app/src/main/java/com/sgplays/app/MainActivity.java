package com.sgplays.app;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private LinearLayout root, header, body, browserBar, playerPanel;
    private EditText address;
    private WebView web;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status, timeLabel, speedButton;
    private Button backButton, forwardButton;
    private ActivityResultLauncher<String[]> filePicker;
    private boolean playingScreen = false;
    private float speed = 1f;
    private int aspectMode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
    private long loopA = -1, loopB = -1;
    private boolean loopEnabled = false;
    private String currentMediaUri = "";
    private final Runnable loopTask = new Runnable() {
        @Override public void run() {
            if (player != null && loopEnabled && loopA >= 0 && loopB > loopA && player.getCurrentPosition() >= loopB) {
                player.seekTo(loopA);
            }
            handler.postDelayed(this, 250);
        }
    };
    private final Runnable savePositionTask = new Runnable() {
        @Override public void run() {
            if (player != null && !currentMediaUri.isEmpty()) {
                getPreferences(MODE_PRIVATE).edit()
                    .putString("last_uri", currentMediaUri)
                    .putLong("position_" + currentMediaUri.hashCode(), player.getCurrentPosition())
                    .apply();
            }
            handler.postDelayed(this, 5000);
        }
    };
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF090A10);
        getWindow().setNavigationBarColor(0xFF090A10);
        filePicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) {}
                openPlayer(uri.toString(), "Local media");
            }
        });
        buildHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(0xFFF5F5FA);
        t.setTextSize(size); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String value) {
        Button b = new Button(this); b.setText(value); b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF29243A));
        return b;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void buildBase(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFF090A10);
        header = row(); header.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView brand = text(title, 21); brand.setTypeface(null, 1);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(header);
        setContentView(root);
    }
    private void buildHome() {
        if (player != null) {
            if (!currentMediaUri.isEmpty()) getPreferences(MODE_PRIVATE).edit()
                .putString("last_uri", currentMediaUri)
                .putLong("position_" + currentMediaUri.hashCode(), player.getCurrentPosition()).apply();
            player.release(); player = null;
        }
        if (web != null) { web.destroy(); web = null; }
        playingScreen = false;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildBase("SG_PLAYS");
        TextView tagline = text("Your lectures. Your player. Your control.", 14);
        tagline.setPadding(dp(16), dp(4), dp(16), dp(14)); tagline.setTextColor(0xFFB9B5C8);
        root.addView(tagline);
        LinearLayout actions = row(); actions.setPadding(dp(12), 0, dp(12), dp(8));
        Button browser = button("Open Browser"); browser.setOnClickListener(v -> buildBrowser("https://www.google.com"));
        Button files = button("Import Media"); files.setOnClickListener(v -> filePicker.launch(new String[]{"video/*","audio/*"}));
        actions.addView(browser, new LinearLayout.LayoutParams(0, dp(52), 1));
        actions.addView(files, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(actions);
        LinearLayout more = row(); more.setPadding(dp(12), 0, dp(12), dp(8));
        Button history = button("Last Lecture"); history.setOnClickListener(v -> {
            String last = getPreferences(MODE_PRIVATE).getString("last_uri", "");
            if (!last.isEmpty()) openPlayer(last, "Last lecture");
            else Toast.makeText(this, "No previous lecture yet", Toast.LENGTH_SHORT).show();
        });
        Button saved = button("Study Notes"); saved.setOnClickListener(v -> showSavedNotes());
        more.addView(history, new LinearLayout.LayoutParams(0, dp(48), 1));
        more.addView(saved, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(more);
        TextView info = text("QUICK ACCESS", 12); info.setTextColor(0xFF9B8FAF);
        info.setPadding(dp(16), dp(18), dp(16), dp(8)); root.addView(info);
        Button study = button("Open StudyRays"); study.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        study.setPadding(dp(18),0,0,0); study.setOnClickListener(v -> buildBrowser("https://studyrays.com"));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(dp(12),0,dp(12),dp(8)); root.addView(study,p);
        TextView note = text("Tip: Open a directly playable video URL in the browser, or use Import Media for files on your phone.", 13);
        note.setTextColor(0xFFAAA6B5); note.setPadding(dp(16), dp(18), dp(16), dp(16)); root.addView(note);
    }

    private void buildBrowser(String startUrl) {
        playingScreen = false;
        buildBase("SG_PLAYS  •  Browser");
        browserBar = row(); browserBar.setPadding(dp(8), dp(4), dp(8), dp(8));
        backButton = button("‹"); forwardButton = button("›");
        Button refresh = button("↻"), copy = button("Copy");
        address = new EditText(this); address.setSingleLine(true); address.setTextColor(0xFFFFFFFF);
        address.setHintTextColor(0xFFAAA6B5); address.setHint("Enter website or video URL");
        address.setText(startUrl); address.setTextSize(14); address.setPadding(dp(10),0,dp(10),0);
        address.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6D5B91));
        browserBar.addView(backButton, new LinearLayout.LayoutParams(dp(42),dp(46)));
        browserBar.addView(forwardButton, new LinearLayout.LayoutParams(dp(42),dp(46)));
        browserBar.addView(address, new LinearLayout.LayoutParams(0,dp(46),1));
        browserBar.addView(refresh, new LinearLayout.LayoutParams(dp(48),dp(46)));
        browserBar.addView(copy, new LinearLayout.LayoutParams(dp(62),dp(46)));
        root.addView(browserBar);
        Button go = button("Go"); go.setOnClickListener(v -> loadAddress());
        LinearLayout nav = row(); nav.setPadding(dp(8),0,dp(8),dp(6));
        Button home = button("Home"), openPlayer = button("Open in Player");
        home.setOnClickListener(v -> buildHome());
        openPlayer.setOnClickListener(v -> openPlayer(address.getText().toString().trim(), "Web video"));
        nav.addView(home, new LinearLayout.LayoutParams(0,dp(42),1));
        nav.addView(go, new LinearLayout.LayoutParams(0,dp(42),1));
        nav.addView(openPlayer, new LinearLayout.LayoutParams(0,dp(42),1));
        root.addView(nav);
        web = new WebView(this); web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true); web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (isDirectMedia(u)) { openPlayer(u, "Web video"); return true; }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                address.setText(url); backButton.setEnabled(view.canGoBack()); forwardButton.setEnabled(view.canGoForward());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        backButton.setOnClickListener(v -> { if(web.canGoBack()) web.goBack(); });
        forwardButton.setOnClickListener(v -> { if(web.canGoForward()) web.goForward(); });
        refresh.setOnClickListener(v -> web.reload());
        copy.setOnClickListener(v -> {
            ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("URL", address.getText()));
            Toast.makeText(this,"URL copied",Toast.LENGTH_SHORT).show();
        });
        go.setOnClickListener(v -> loadAddress());
        address.setOnEditorActionListener((v, action, event) -> { loadAddress(); return true; });
        web.loadUrl(startUrl);
    }
    private void loadAddress() {
        String u = address.getText().toString().trim();
        if (!u.matches("(?i)^https?://.*")) u = "https://" + u;
        web.loadUrl(u);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
    }
    private boolean isDirectMedia(String u) {
        String s = u.toLowerCase(Locale.US).split("\\?")[0];
        return s.endsWith(".mp4") || s.endsWith(".m3u8") || s.endsWith(".mpd") || s.endsWith(".webm") || s.endsWith(".mp3") || s.endsWith(".m4a");
    }

    private void openPlayer(String uri, String title) {
        if (uri == null || uri.trim().isEmpty()) return;
        if (web != null) { web.destroy(); web = null; }
        if (player != null) { player.release(); player = null; }
        playingScreen = true;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        buildBase("SG_PLAYS");
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(3500);
        root.addView(playerView, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout controls = row(); controls.setGravity(Gravity.CENTER); controls.setPadding(dp(6),dp(4),dp(6),dp(4));
        Button back = button("‹ Exit"), minus = button("−10s"), play = button("Play/Pause"), plus = button("+10s");
        speedButton = text("1.0×",16); speedButton.setGravity(Gravity.CENTER); speedButton.setPadding(dp(10),0,dp(10),0);
        back.setOnClickListener(v -> buildHome());
        minus.setOnClickListener(v -> seekBy(-10000));
        plus.setOnClickListener(v -> seekBy(10000));
        play.setOnClickListener(v -> { if(player != null) { if(player.isPlaying()) player.pause(); else player.play(); }});
        speedButton.setOnClickListener(v -> {
            float[] speeds = new float[]{0.5f,0.75f,1f,1.25f,1.5f,1.75f,2f,2.5f,3f,4f};
            int next = 0;
            for (int i=0;i<speeds.length;i++) if (Math.abs(speeds[i]-speed)<0.01f) next=(i+1)%speeds.length;
            speed = speeds[next];
            if(player != null) player.setPlaybackSpeed(speed);
            speedButton.setText(String.format(Locale.US,"%.2f×",speed));
        });
        controls.addView(back); controls.addView(minus); controls.addView(play); controls.addView(plus); controls.addView(speedButton);
        root.addView(controls);

        LinearLayout tools = row(); tools.setGravity(Gravity.CENTER); tools.setPadding(dp(4),dp(2),dp(4),dp(6));
        Button mark = button("Bookmark"), note = button("Note"), ab = button("A–B Loop"), timer = button("Sleep"), ratio = button("Ratio");
        mark.setOnClickListener(v -> saveBookmark());
        note.setOnClickListener(v -> addTimestampNote());
        ab.setOnClickListener(v -> toggleABLoop(ab));
        timer.setOnClickListener(v -> chooseSleepTimer());
        ratio.setOnClickListener(v -> cycleAspectRatio());
        tools.addView(mark); tools.addView(note); tools.addView(ab); tools.addView(timer); tools.addView(ratio);
        root.addView(tools);

        currentMediaUri = uri;
        loopA = -1; loopB = -1; loopEnabled = false;
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(Uri.parse(uri)));
        long resume = getPreferences(MODE_PRIVATE).getLong("position_" + uri.hashCode(), 0);
        player.prepare();
        if (resume > 3000) player.seekTo(resume);
        player.play();
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
                Toast.makeText(MainActivity.this,"Cannot play this source: " + error.getErrorCodeName(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private void saveBookmark() {
        if (player == null) return;
        String key = "bookmarks_" + currentMediaUri.hashCode();
        String old = getPreferences(MODE_PRIVATE).getString(key, "");
        String entry = player.getCurrentPosition() + "|" + currentMediaUri;
        getPreferences(MODE_PRIVATE).edit().putString(key, old.isEmpty() ? entry : old + "\n" + entry).apply();
        Toast.makeText(this, "Bookmark saved at " + formatTime(player.getCurrentPosition()), Toast.LENGTH_SHORT).show();
    }

    private String formatTime(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%02d:%02d:%02d", sec/3600, (sec%3600)/60, sec%60);
    }

    private void addTimestampNote() {
        if (player == null) return;
        EditText input = new EditText(this);
        input.setHint("Write a note for this moment");
        input.setMinLines(2);
        new AlertDialog.Builder(this).setTitle("Lecture note • " + formatTime(player.getCurrentPosition()))
            .setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save", (d,w) -> {
                String key = "notes_" + currentMediaUri.hashCode();
                String old = getPreferences(MODE_PRIVATE).getString(key, "");
                String line = formatTime(player.getCurrentPosition()) + " — " + input.getText().toString().trim();
                getPreferences(MODE_PRIVATE).edit().putString(key, old.isEmpty() ? line : old + "\n" + line).apply();
                Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
            }).show();
    }

    private void showSavedNotes() {
        StringBuilder all = new StringBuilder();
        for (String k : getPreferences(MODE_PRIVATE).getAll().keySet()) {
            if (k.startsWith("notes_") || k.startsWith("bookmarks_")) {
                Object value = getPreferences(MODE_PRIVATE).getAll().get(k);
                if (value instanceof String && !((String)value).isEmpty()) {
                    all.append(k.startsWith("notes_") ? "NOTES\n" : "BOOKMARKS\n")
                       .append(value).append("\n\n");
                }
            }
        }
        if (all.length() == 0) all.append("Your saved lecture notes and bookmarks will appear here.");
        new AlertDialog.Builder(this).setTitle("Your Study Library").setMessage(all.toString())
            .setPositiveButton("Close", null).show();
    }

    private void toggleABLoop(Button button) {
        if (player == null) return;
        if (!loopEnabled) {
            if (loopA < 0 || loopB >= 0) {
                loopA = player.getCurrentPosition(); loopB = -1;
                button.setText("Set B point");
                Toast.makeText(this, "A point: " + formatTime(loopA) + ". Seek forward and tap again.", Toast.LENGTH_LONG).show();
            } else {
                loopB = player.getCurrentPosition();
                if (loopB <= loopA + 500) {
                    loopA = loopB = -1; button.setText("A–B Loop");
                    Toast.makeText(this, "B must be after A by at least half a second", Toast.LENGTH_SHORT).show();
                    return;
                }
                loopEnabled = true; button.setText("Loop ON");
                Toast.makeText(this, "A–B loop enabled", Toast.LENGTH_SHORT).show();
            }
        } else {
            loopEnabled = false; loopA = loopB = -1; button.setText("A–B Loop");
            Toast.makeText(this, "A–B loop disabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseSleepTimer() {
        String[] choices = {"15 minutes", "30 minutes", "45 minutes", "60 minutes", "Cancel timer"};
        new AlertDialog.Builder(this).setTitle("Sleep timer").setItems(choices, (d, which) -> {
            handler.removeCallbacksAndMessages("sleep");
            if (which == 4) { Toast.makeText(this, "Sleep timer cancelled", Toast.LENGTH_SHORT).show(); return; }
            long delay = (which + 1) * 15L * 60L * 1000L;
            Runnable stop = () -> { if (player != null) player.pause(); Toast.makeText(this, "Sleep timer paused playback", Toast.LENGTH_LONG).show(); };
            handler.postAtTime(stop, "sleep", SystemClock.uptimeMillis() + delay);
            Toast.makeText(this, choices[which] + " sleep timer set", Toast.LENGTH_SHORT).show();
        }).show();
    }

    private void cycleAspectRatio() {
        if (playerView == null) return;
        aspectMode = aspectMode == AspectRatioFrameLayout.RESIZE_MODE_FIT ? AspectRatioFrameLayout.RESIZE_MODE_FILL :
                     aspectMode == AspectRatioFrameLayout.RESIZE_MODE_FILL ? AspectRatioFrameLayout.RESIZE_MODE_ZOOM :
                     AspectRatioFrameLayout.RESIZE_MODE_FIT;
        int next = aspectMode;
        playerView.setResizeMode(next);
        String label = next == AspectRatioFrameLayout.RESIZE_MODE_FIT ? "Fit" :
                       next == AspectRatioFrameLayout.RESIZE_MODE_FILL ? "Stretch" : "Zoom";
        Toast.makeText(this, "Aspect ratio: " + label, Toast.LENGTH_SHORT).show();
    }

    private void seekBy(long amount) {
        if(player == null) return;
        long target = Math.max(0, Math.min(player.getDuration() > 0 ? player.getDuration() : Long.MAX_VALUE, player.getCurrentPosition()+amount));
        player.seekTo(target);
    }
    @Override public void onBackPressed() {
        if (playingScreen) { buildHome(); return; }
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }
    @Override protected void onDestroy() {
        handler.removeCallbacks(loopTask);
        handler.removeCallbacks(savePositionTask);
        if (player != null) {
            if (!currentMediaUri.isEmpty()) getPreferences(MODE_PRIVATE).edit()
                .putString("last_uri", currentMediaUri)
                .putLong("position_" + currentMediaUri.hashCode(), player.getCurrentPosition()).apply();
            player.release(); player = null;
        }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
